package com.example.demo.Dto;



public class StudentDto {
	
	private Integer id;
	private String name;
	private String email;
	private String contactNo;
	private String altContactNo;
	private String dob;
	private String currentAddress;
	private String permanentAddress;
	private String graduationField;
	private String passoutYear;
	private String working;
	private String role;
	private String courseName;
	private String duration;
	private String courseType;
	private String location;
	private String startDate ;
	private String endDate;
	private String totalAmount;
	private String firstInstallment;
	private String firstInstallmentDate;
	private String secondInstallment;
	private String secondInstallmentDate;
	private String thirdInstallment;
	private String thirdInstallmentDate;
	
	public StudentDto() {
		
	}

	public StudentDto(Integer id, String name, String email, String contactNo, String altContactNo, String dob,
			String currentAddress, String permanentAddress, String graduationField, String passoutYear, String working,
			String role, String courseName, String duration, String courseType, String location, String startDate,
			String endDate, String totalAmount, String firstInstallment, String firstInstallmentDate,
			String secondInstallment, String secondInstallmentDate, String thirdInstallment,
			String thirdInstallmentDate) {
		
		this.id = id;
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.altContactNo = altContactNo;
		this.dob = dob;
		this.currentAddress = currentAddress;
		this.permanentAddress = permanentAddress;
		this.graduationField = graduationField;
		this.passoutYear = passoutYear;
		this.working = working;
		this.role = role;
		this.courseName = courseName;
		this.duration = duration;
		this.courseType = courseType;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.totalAmount = totalAmount;
		this.firstInstallment = firstInstallment;
		this.firstInstallmentDate = firstInstallmentDate;
		this.secondInstallment = secondInstallment;
		this.secondInstallmentDate = secondInstallmentDate;
		this.thirdInstallment = thirdInstallment;
		this.thirdInstallmentDate = thirdInstallmentDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getAltContactNo() {
		return altContactNo;
	}

	public void setAltContactNo(String altContactNo) {
		this.altContactNo = altContactNo;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getCurrentAddress() {
		return currentAddress;
	}

	public void setCurrentAddress(String currentAddress) {
		this.currentAddress = currentAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getGraduationField() {
		return graduationField;
	}

	public void setGraduationField(String graduationField) {
		this.graduationField = graduationField;
	}

	public String getPassoutYear() {
		return passoutYear;
	}

	public void setPassoutYear(String passoutYear) {
		this.passoutYear = passoutYear;
	}

	public String getWorking() {
		return working;
	}

	public void setWorking(String working) {
		this.working = working;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getCourseType() {
		return courseType;
	}

	public void setCourseType(String courseType) {
		this.courseType = courseType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getFirstInstallment() {
		return firstInstallment;
	}

	public void setFirstInstallment(String firstInstallment) {
		this.firstInstallment = firstInstallment;
	}

	public String getFirstInstallmentDate() {
		return firstInstallmentDate;
	}

	public void setFirstInstallmentDate(String firstInstallmentDate) {
		this.firstInstallmentDate = firstInstallmentDate;
	}

	public String getSecondInstallment() {
		return secondInstallment;
	}

	public void setSecondInstallment(String secondInstallment) {
		this.secondInstallment = secondInstallment;
	}

	public String getSecondInstallmentDate() {
		return secondInstallmentDate;
	}

	public void setSecondInstallmentDate(String secondInstallmentDate) {
		this.secondInstallmentDate = secondInstallmentDate;
	}

	public String getThirdInstallment() {
		return thirdInstallment;
	}

	public void setThirdInstallment(String thirdInstallment) {
		this.thirdInstallment = thirdInstallment;
	}

	public String getThirdInstallmentDate() {
		return thirdInstallmentDate;
	}

	public void setThirdInstallmentDate(String thirdInstallmentDate) {
		this.thirdInstallmentDate = thirdInstallmentDate;
	}
	
	
	
	
	}
	
	


