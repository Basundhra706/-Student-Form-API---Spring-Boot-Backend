package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.Dto.StudentDto;

public interface StudentService {

    // Add a new student
    StudentDto addStudent(StudentDto studentDto);

    // Find a student by email
    StudentDto findStudentByEmail(String email);

    // Find students by contact number
    List<StudentDto> findStudentsByContactNo(String contactNo);

    // Update an existing student
    StudentDto updateStudent(Integer id, StudentDto studentDto);

    // Get a student by ID
    Optional<StudentDto> getStudentById(Integer id);

    // Get all students
    List<StudentDto> getAllStudents();

    // Delete a student by ID
    void deleteStudent(Integer id);

    // Get students by course name
    List<StudentDto> getStudentsByCourseName(String courseName);

    // Get students by graduation year
    List<StudentDto> getStudentsByGraduationYear(String graduationYear);
}
