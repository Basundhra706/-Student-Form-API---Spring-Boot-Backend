package com.example.demo.service.implementation;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dto.StudentDto;
import com.example.demo.Entity.StudentEntity;
import com.example.demo.repository.StudentRepo;
import com.example.demo.service.StudentService;

@Service
public class StudentServiceImple implements StudentService {

    @Autowired
    private StudentRepo studentRepo;

    @Override
    public StudentDto addStudent(StudentDto studentDto) {
        StudentEntity studentEntity = convertDtoToEntity(studentDto);
        StudentEntity savedStudent = studentRepo.save(studentEntity);
        return convertEntityToDto(savedStudent);
    }

    @Override
    public StudentDto findStudentByEmail(String email) {
        StudentEntity studentEntity = studentRepo.findByEmail(email);
        return studentEntity != null ? convertEntityToDto(studentEntity) : null;
    }

    @Override
    public List<StudentDto> findStudentsByContactNo(String contactNo) {
        List<StudentEntity> studentEntities = studentRepo.findByContactNo(contactNo);
        return studentEntities.stream()
                .map(this::convertEntityToDto)
                .collect(Collectors.toList());
    }

    @Override
    public StudentDto updateStudent(Integer id, StudentDto studentDto) {
        Optional<StudentEntity> existingStudentOpt = studentRepo.findById(id);
        if (existingStudentOpt.isPresent()) {
            StudentEntity existingStudent = existingStudentOpt.get();

            // Update fields
            existingStudent.setName(studentDto.getName());
            existingStudent.setEmail(studentDto.getEmail());
            existingStudent.setContactNo(studentDto.getContactNo());
            existingStudent.setAltContactNo(studentDto.getAltContactNo());
            existingStudent.setDob(studentDto.getDob());
            existingStudent.setCurrentAddress(studentDto.getCurrentAddress());
            existingStudent.setPermanentAddress(studentDto.getPermanentAddress());
            existingStudent.setGraduationField(studentDto.getGraduationField());
            existingStudent.setPassoutYear(studentDto.getPassoutYear());
            existingStudent.setWorking(studentDto.getWorking());
            existingStudent.setRole(studentDto.getRole());
            existingStudent.setCourseName(studentDto.getCourseName());
            existingStudent.setDuration(studentDto.getDuration());
            existingStudent.setCourseType(studentDto.getCourseType());
            existingStudent.setLocation(studentDto.getLocation());
            existingStudent.setStartDate(studentDto.getStartDate());
            existingStudent.setEndDate(studentDto.getEndDate());
            existingStudent.setTotalAmount(studentDto.getTotalAmount());
            existingStudent.setFirstInstallment(studentDto.getFirstInstallment());
            existingStudent.setSecondInstallment(studentDto.getSecondInstallment());
            existingStudent.setThirdInstallment(studentDto.getThirdInstallment());
            existingStudent.setFirstInstallmentDate(studentDto.getFirstInstallmentDate());
            existingStudent.setSecondInstallmentDate(studentDto.getSecondInstallmentDate());
            existingStudent.setThirdInstallmentDate(studentDto.getThirdInstallmentDate());
            
            StudentEntity updatedStudent = studentRepo.save(existingStudent);
            return convertEntityToDto(updatedStudent);
        }
        return null;
    }

    @Override
    public Optional<StudentDto> getStudentById(Integer id) {
        Optional<StudentEntity> studentOpt = studentRepo.findById(id);
        return studentOpt.map(this::convertEntityToDto);
    }

    @Override
    public List<StudentDto> getAllStudents() {
        List<StudentEntity> students = studentRepo.findAll();
        return students.stream()
                .map(this::convertEntityToDto)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteStudent(Integer id) {
        studentRepo.deleteById(id);
    }

    @Override
    public List<StudentDto> getStudentsByCourseName(String courseName) {
        List<StudentEntity> students = studentRepo.findByCourseName(courseName);
        return students.stream()
                .map(this::convertEntityToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<StudentDto> getStudentsByGraduationYear(String graduationYear) {
        List<StudentEntity> students = studentRepo.findByPassoutYear(graduationYear);
        return students.stream()
                .map(this::convertEntityToDto)
                .collect(Collectors.toList());
    }

    // Convert Entity to DTO
    private StudentDto convertEntityToDto(StudentEntity studentEntity) {
        StudentDto studentDto = new StudentDto();
        //studentDto.setID(studentEntity.getID());
        studentDto.setName(studentEntity.getName());
        studentDto.setEmail(studentEntity.getEmail());
        studentDto.setContactNo(studentEntity.getContactNo());
        studentDto.setAltContactNo(studentEntity.getAltContactNo());
        studentDto.setDob(studentEntity.getDob());
        studentDto.setCurrentAddress(studentEntity.getCurrentAddress());
        studentDto.setPermanentAddress(studentEntity.getPermanentAddress());
        studentDto.setGraduationField(studentEntity.getGraduationField());
        studentDto.setPassoutYear(studentEntity.getPassoutYear());
        studentDto.setWorking(studentEntity.getWorking());
        studentDto.setRole(studentEntity.getRole());
        studentDto.setCourseName(studentEntity.getCourseName());
        studentDto.setDuration(studentEntity.getDuration());
        studentDto.setCourseType(studentEntity.getCourseType());
        studentDto.setLocation(studentEntity.getLocation());
        studentDto.setStartDate(studentEntity.getStartDate());
        studentDto.setEndDate(studentEntity.getEndDate());
        studentDto.setTotalAmount(studentEntity.getTotalAmount());
        studentDto.setFirstInstallment(studentEntity.getFirstInstallment());
        studentDto.setSecondInstallment(studentEntity.getSecondInstallment());
        studentDto.setThirdInstallment(studentEntity.getThirdInstallment());
        studentDto.setFirstInstallmentDate(studentEntity.getFirstInstallmentDate());
        studentDto.setSecondInstallmentDate(studentEntity.getSecondInstallmentDate());
        studentDto.setThirdInstallmentDate(studentEntity.getThirdInstallmentDate());
        
        return studentDto;
    }

    // Convert DTO to Entity
    private StudentEntity convertDtoToEntity(StudentDto studentDto) {
        StudentEntity studentEntity = new StudentEntity();
        studentEntity.setName(studentDto.getName());
        studentEntity.setEmail(studentDto.getEmail());
        studentEntity.setContactNo(studentDto.getContactNo());
        studentEntity.setAltContactNo(studentDto.getAltContactNo());
        studentEntity.setDob(studentDto.getDob());
        studentEntity.setCurrentAddress(studentDto.getCurrentAddress());
        studentEntity.setPermanentAddress(studentDto.getPermanentAddress());
        studentEntity.setGraduationField(studentDto.getGraduationField());
        studentEntity.setPassoutYear(studentDto.getPassoutYear());
        studentEntity.setWorking(studentDto.getWorking());
        studentEntity.setRole(studentDto.getRole());
        studentEntity.setCourseName(studentDto.getCourseName());
        studentEntity.setDuration(studentDto.getDuration());
        studentEntity.setCourseType(studentDto.getCourseType());
        studentEntity.setLocation(studentDto.getLocation());
        studentEntity.setStartDate(studentDto.getStartDate());
        studentEntity.setEndDate(studentDto.getEndDate());
        studentEntity.setTotalAmount(studentDto.getTotalAmount());
        studentEntity.setFirstInstallment(studentDto.getFirstInstallment());
        studentEntity.setSecondInstallment(studentDto.getSecondInstallment());
        studentEntity.setThirdInstallment(studentDto.getThirdInstallment());
        studentEntity.setFirstInstallmentDate(studentDto.getFirstInstallmentDate());
        studentEntity.setSecondInstallmentDate(studentDto.getSecondInstallmentDate());
        studentEntity.setThirdInstallmentDate(studentDto.getThirdInstallmentDate());
        
        return studentEntity;
    }
}