package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.StudentEntity;

public interface StudentRepo extends JpaRepository<StudentEntity, Integer> {
    
	   StudentEntity findByEmail(String email);	
	   
	   List<StudentEntity> findByCourseName(String courseName);

	    List<StudentEntity> findByPassoutYear(String graduationYear);

		List<StudentEntity> findByContactNo(String contactNo);

}
