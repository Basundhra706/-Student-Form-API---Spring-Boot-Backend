package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration

public class SecurirtyConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable() // disable CSRF for REST APIs
            .authorizeHttpRequests()
                .requestMatchers("/add", "/all").permitAll() // ✅ open these to everyone
                .requestMatchers("/auth/**").authenticated() // ✅ secure these
                .anyRequest().permitAll() // open anything else for now
            .and()
            .httpBasic(); // or use formLogin() if you have a login UI

        return http.build();
    }
}