package com.example.demo.Controller;

import com.example.demo.Dto.StudentDto;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "http://localhost:5173/")
public class StudentController {

    @Autowired
    private StudentService studentService;

    // Add a new student
    @PostMapping("/add")
    public ResponseEntity<StudentDto> addStudent(@RequestBody StudentDto studentDto) {
        StudentDto createdStudent = studentService.addStudent(studentDto);
        return new ResponseEntity<>(createdStudent, HttpStatus.CREATED);
    }

    // Get student by ID
    @GetMapping("/id")
    public ResponseEntity<StudentDto> getStudentById(@PathVariable Integer id) {
        Optional<StudentDto> studentDto = studentService.getStudentById(id);
        return studentDto.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    // Get student by email
    @GetMapping("/email/{email}")
    public ResponseEntity<StudentDto> getStudentByEmail(@PathVariable String email) {
        StudentDto studentDto = studentService.findStudentByEmail(email);
        return studentDto != null ? ResponseEntity.ok(studentDto)
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    // Get students by contact number
    @GetMapping("/contact/{contactNo}")
    public ResponseEntity<List<StudentDto>> getStudentsByContactNo(@PathVariable String contactNo) {
        List<StudentDto> studentDtos = studentService.findStudentsByContactNo(contactNo);
        return studentDtos.isEmpty() ? ResponseEntity.status(HttpStatus.NOT_FOUND).build()
                : ResponseEntity.ok(studentDtos);
    }

    // Get all students
    @GetMapping("/all")
    public ResponseEntity<List<StudentDto>> getAllStudents() {
        List<StudentDto> studentDtos = studentService.getAllStudents();
        return studentDtos.isEmpty() ? ResponseEntity.status(HttpStatus.NOT_FOUND).build()
                : ResponseEntity.ok(studentDtos);
    }

    // Update student by ID
    @PutMapping("/{id}")
    public ResponseEntity<StudentDto> updateStudent(@PathVariable Integer id, @RequestBody StudentDto studentDto) {
        StudentDto updatedStudent = studentService.updateStudent(id, studentDto);
        return updatedStudent != null ? ResponseEntity.ok(updatedStudent)
                : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    // Delete student by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Integer id) {
        studentService.deleteStudent(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    // Get students by course name
    @GetMapping("/course/{courseName}")
    public ResponseEntity<List<StudentDto>> getStudentsByCourseName(@PathVariable String courseName) {
        List<StudentDto> studentDtos = studentService.getStudentsByCourseName(courseName);
        return studentDtos.isEmpty() ? ResponseEntity.status(HttpStatus.NOT_FOUND).build()
                : ResponseEntity.ok(studentDtos);
    }

    // Get students by graduation year
    @GetMapping("/graduation-year/{graduationYear}")
    public ResponseEntity<List<StudentDto>> getStudentsByGraduationYear(@PathVariable String graduationYear) {
        List<StudentDto> studentDtos = studentService.getStudentsByGraduationYear(graduationYear);
        return studentDtos.isEmpty() ? ResponseEntity.status(HttpStatus.NOT_FOUND).build()
                : ResponseEntity.ok(studentDtos);
    }
}
